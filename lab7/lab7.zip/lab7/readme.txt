You should reuse the lab4 & lab6 code in lab7.
